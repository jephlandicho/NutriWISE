<footer class="site-footer">
				<div class="container">
					<i class=""></i>
					<nav class="footer-navigation">
						<a href="about.php">About US</a>
						<a href="offer.php">Offer</a>
						<a href="sample.php">Sample Meal Plan</a>
						<a href="contact.php">Contact</a>
						<a href="app.php">Download Our App</a>
					</nav>
					
					<div class="social-links">
						<a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
						<a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
						<a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a>
						<a href="#" class="pinterest"><i class="fa fa-pinterest"></i></a>
					</div>
					<div class="colophon">
						<p>Copyright 2023 NutriWise. <br> Alright reserved</p>
					</div>
				</div>
			</footer>
